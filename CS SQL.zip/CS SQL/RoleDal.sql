﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IDAL;
using Model;

namespace CZBK.OADemo.DAL
{
    //public partial class RoleDal : BaseDal<Role>,IRoleDal
    //{
       
    //}
}
