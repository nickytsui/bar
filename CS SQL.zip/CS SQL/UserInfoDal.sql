﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using IDAL;
using Model;

namespace CZBK.OADemo.DAL
{
    //public partial class UserInfoDal :BaseDal<UserInfo>,IUserInfoDal
    //{

    //    //单元测试：没有很好的进行测试的入口的时候的单元测试是最佳的方式。
    //    //能够极大的提高开发效率。
    //    //牛逼1：可以通过单元测试进行项目的进度的控制。
    //    //单元测试也其实是另外一种设计。
    //    //牛逼2：单元测试是非常好的学习第三方的工具。
    //    //单元测试可以进行辅助我们进行 压力测试。

    //    //lr:  loadrunner  hp

    //   // DataModelContainer db = new DataModelContainer();

    //    #region old
    //    //public UserInfo Add(UserInfo userInfo)
    //    //{
    //    //   //单元测试

    //    //    db.UserInfo.Add(userInfo);
    //    //    db.SaveChanges();//保存完了之后，会自动将自动增长的属性放到 我们的id属性上去。

    //    //    return userInfo;
    //    //}


    //    //public bool Update(UserInfo userInfo)
    //    //{
    //    //    db.UserInfo.Attach(userInfo);
    //    //    db.Entry(userInfo).State = EntityState.Modified;
    //    //    return db.SaveChanges() > 0;
    //    //}

    //    //public bool Delete(UserInfo userInfo)
    //    //{
    //    //    db.UserInfo.Attach(userInfo);
    //    //    db.Entry(userInfo).State = EntityState.Deleted;
    //    //    return db.SaveChanges() > 0;
    //    //}

    //    //public int Delete(params int[] ids)
    //    //{
    //    //    foreach (var id in ids)
    //    //    {
    //    //        UserInfo user =new UserInfo();
    //    //        user.ID = id;
    //    //        db.Entry(user).State = EntityState.Deleted;
    //    //    }

    //    //    return db.SaveChanges();
    //    //}


    //    // /// <summary>
    //    // /// 基本查询
    //    // /// </summary>
    //    // /// <param name="whereLambda"></param>
    //    // /// <returns></returns>
    //    //public IQueryable<UserInfo> LoadUserInfos(Func<UserInfo,bool> whereLambda )
    //    //{
    //    //    //分页



    //    //    //int total = 0;
    //    //    //this.LoadPageUserInfos<string>(5, 1, out total, u => true, s => s.Pwd, true);


    //    //    return db.UserInfo.Where(whereLambda).AsQueryable();


    //    //}


    //    // /// <summary>
    //    // /// 分页
    //    // /// </summary>
    //    // /// <typeparam name="S"></typeparam>
    //    // /// <param name="pageSize"></param>
    //    // /// <param name="pageIndex"></param>
    //    // /// <param name="total"></param>
    //    // /// <param name="whereLambda"></param>
    //    // /// <param name="orderbyLambda"></param>
    //    // /// <param name="isAsc"></param>
    //    // /// <returns></returns>
    //    //public IQueryable<UserInfo> LoadPageUserInfos<S>(int pageSize, int pageIndex, out int total, Func<UserInfo, bool> whereLambda
    //    //    ,Func<UserInfo,S> orderbyLambda,bool isAsc)
    //    //{
    //    //    total = db.UserInfo.Where(whereLambda).Count();

    //    //    if (isAsc)
    //    //    {

    //    //        return db.UserInfo.Where(whereLambda).OrderBy(orderbyLambda)
    //    //                 .Skip<UserInfo>(pageSize*(pageIndex - 1))
    //    //                 .Take<UserInfo>(pageSize).AsQueryable();
    //    //    }
    //    //    else
    //    //    {

    //    //        return db.UserInfo.Where(whereLambda).OrderByDescending(orderbyLambda)
    //    //                 .Skip(pageSize * (pageIndex - 1))
    //    //                 .Take(pageSize).AsQueryable();
    //    //    }


    //    //} 
    //    #endregion


    //    //public UserInfo Add(UserInfo entity)
    //    //{
    //    //    throw new NotImplementedException();
    //    //}

    //    //public bool Update(UserInfo entity)
    //    //{
    //    //    throw new NotImplementedException();
    //    //}

    //    //public bool Delete(UserInfo entity)
    //    //{
    //    //    throw new NotImplementedException();
    //    //}

    //    //public int Delete(params int[] ids)
    //    //{
    //    //    throw new NotImplementedException();
    //    //}

    //    //public IQueryable<UserInfo> LoadEntities(Func<UserInfo, bool> whereLambda)
    //    //{
    //    //    throw new NotImplementedException();
    //    //}

    //    //public IQueryable<UserInfo> LoadPageEntities<S>(int pageSize, int pageIndex, out int total, Func<UserInfo, bool> whereLambda, Func<UserInfo, S> orderbyLambda, bool isAsc)
    //    //{
    //    //    throw new NotImplementedException();
    //    //}
    //}
}
