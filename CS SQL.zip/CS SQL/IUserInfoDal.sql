﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Model;

namespace IDAL
{
    //dry: dont repeat  yourself


    //public partial interface IUserInfoDal :IBaseDal<UserInfo>
    //{
    //    //UserInfo Add(UserInfo userInfo);

    //    //bool Update(UserInfo userInfo);

    //    //bool Delete(UserInfo userInfo);

    //    //int Delete(params int[] ids);

    //    ////u=>true
    //    //IQueryable<UserInfo> LoadUserInfos(Func<UserInfo,bool> whereLambda );//规约设计模式。 where a>10

    //    //IQueryable<UserInfo> LoadPageUserInfos<S>(int pageSize, int pageIndex, out int total,
    //    //                                          Func<UserInfo, bool> whereLambda
    //    //                                          , Func<UserInfo, S> orderbyLambda, bool isAsc);




    //}
}
