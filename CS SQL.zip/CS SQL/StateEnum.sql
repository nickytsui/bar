﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UI.Models
{
    
    public enum StateEnum
    {
        Normal = 0,
        Prohibit = 1
    }
    public enum ISPaly
    {

    }



}