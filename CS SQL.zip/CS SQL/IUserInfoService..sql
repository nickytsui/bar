﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Model;

namespace IBLL
{
    //public partial interface IUserInfoService:IBLL.IBaseService<UserInfo>
    //{
    //}
}
