﻿ 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IDAL;
using Model;

namespace DAL
{
   
	 //public partial class DepartmentDal : BaseDal<Department>,IDepartmentDal
  //  {
       
  //  }	
	 //public partial class RoleDal : BaseDal<Role>,IRoleDal
  //  {
       
  //  }	
	 //public partial class UserInfoDal : BaseDal<UserInfo>,IUserInfoDal
  //  {
       
  //  }	
	
}