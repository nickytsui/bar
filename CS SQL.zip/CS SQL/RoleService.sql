﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using Model;

//namespace BLL
//{
//    public partial class RoleService:BaseService<Role>,IBLL.IRoleService
//    {
//        //public override void SetCurrentDal()
//        //{
//        //    CurrentDal = DbSession.RoleDal;
//        //}
//    }
//}
