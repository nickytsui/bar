﻿ 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Model;

namespace IBLL
{
   
	
	//public  partial interface IDepartmentService :IBaseService<Department>
	//{
 //   }
	
	//public  partial interface IRoleService :IBaseService<Role>
	//{
 //   }
	
	//public  partial interface IUserInfoService :IBaseService<UserInfo>
	//{
 //   }
	
}