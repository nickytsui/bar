﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using CZBK.OADemo.AdoNetDAL;
//using CZBK.OADemo.DAL;
//using CZBK.OADemo.DalFactory;
//using CZBK.OADemo.IBLL;
//using CZBK.OADemo.IDAL;
//using CZBK.OADemo.Model;

//namespace CZBK.OADemo.BLL
//{
//    public partial class UserInfoService :BaseService<UserInfo>,IUserInfoService
//    {
//        //private DAL.UserInfoEFDal _UserInfoEfDal = new UserInfoEFDal();

//        //private  AdoNetDAL.UserInfoAdoNetDal userInfoAdoNet =new UserInfoAdoNetDal();

//        //问题：有可能用EF实现Dal层，有可能用AdoNet实现Dal层，而且有可能不同数据库，sql，oracle，mysql
//        //通过让BLL层去依赖 一个公共的不怎么变化的契约接口。依赖抽象东西。具体的实现在变化的时候，BLL层就不用变化。

//        //IDAL.IUserInfoDal userInfoDal = new UserInfoEFDal();

//        //private IDAL.IUserInfoDal userInfoDal = DalFactory.DALSimpleFactory.GetUserInfoDal();

        
        
//        //DbSession dbSession =new DbSession();//菜菜鸟。



//        //保证DbSession线程内实例唯一。

//        //IDbSession dbSession =new DbSession();//一般鸟

//        //private IDbSession dbSession = DbSessionFactory.GetCurrentDbSession();



//        //使用简单工厂
//        //IDbSession dbSession =new DbSession();//一般开发工程师

//        //使用抽象工厂 ： 稍微中级开发工程师，8k以上


//        //IoC：依赖注入。Spring.Net  Unity  ioc   
//        // java:    ssh    s:struct2=aspnet mvc  spring=>spring.Net  hibernate =>Nhibernate,EF

        
//        //public IDAL.IUserInfoDal userInfoDal = new .UserInfoDal;


//        //new UserInfoEFDal()实例的创建，在很多的services中都有，我们希望能改一个地方，所有创建实例的地方都能改变。

//        //第一个：对变化点进行封装。
//        //第二个：依赖抽象的基类、接口等进行编程。

//        //业务的方法里面一般情况下不只是操作一个表。
//        //public UserInfo AddUserInfo(UserInfo userInfo)
//        //{
//        //    //用户注册场景

//        //    //用户注册完成之后，给Add 一个角色
//        //    dbSession.RoleDal.Add(new Role());


            

//        //    dbSession.RoleDal.Add(new Role());
            
//        //    dbSession.SaveChanges();



//        //    dbSession.RoleDal.Update(new Role());

//        //    dbSession.RoleDal.Add(new Role());


//        //    dbSession.RoleDal.Delete(new Role());



//        //    //操作的UserInfo
//        //    dbSession.UserInfoDal.Add(userInfo);


//        //    dbSession.SaveChanges();



//        //}
//        //public override void SetCurrentDal()
//        //{
//        //    CurrentDal = DbSession.UserInfoDal;


//        //}
//    }
//}
