﻿

using IDAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IDAL
{
	public partial  interface  IDbSession
    {  
		
		//IDepartmentDal DepartmentDal { get; }
		
		//IRoleDal RoleDal { get; }
		
		//IUserInfoDal UserInfoDal { get; }
	}	
}